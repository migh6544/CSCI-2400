/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_348(unsigned *p)
{
    *p = 2425393368U;
}

void setval_389(unsigned *p)
{
    *p = 3284638024U;
}

void setval_419(unsigned *p)
{
    *p = 2428995912U;
}

void setval_388(unsigned *p)
{
    *p = 1925404732U;
}

unsigned addval_356(unsigned x)
{
    return x + 2428995914U;
}

unsigned getval_412()
{
    return 2425393240U;
}

unsigned getval_386()
{
    return 918786648U;
}

unsigned addval_344(unsigned x)
{
    return x + 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_134(unsigned *p)
{
    *p = 3286272330U;
}

unsigned addval_171(unsigned x)
{
    return x + 3281049225U;
}

unsigned getval_121()
{
    return 3767093415U;
}

void setval_156(unsigned *p)
{
    *p = 3224426121U;
}

void setval_429(unsigned *p)
{
    *p = 3380136585U;
}

unsigned addval_385(unsigned x)
{
    return x + 3268839733U;
}

void setval_240(unsigned *p)
{
    *p = 3252717896U;
}

void setval_408(unsigned *p)
{
    *p = 3372275337U;
}

unsigned getval_319()
{
    return 3375942281U;
}

unsigned getval_345()
{
    return 2464188744U;
}

void setval_239(unsigned *p)
{
    *p = 2430601544U;
}

void setval_267(unsigned *p)
{
    *p = 3676356873U;
}

void setval_434(unsigned *p)
{
    *p = 3372796617U;
}

unsigned getval_334()
{
    return 3286272330U;
}

unsigned getval_128()
{
    return 3374896777U;
}

unsigned getval_489()
{
    return 4207400585U;
}

void setval_456(unsigned *p)
{
    *p = 3284830635U;
}

void setval_148(unsigned *p)
{
    *p = 3221799307U;
}

unsigned getval_494()
{
    return 3687107209U;
}

unsigned addval_482(unsigned x)
{
    return x + 3285617131U;
}

unsigned getval_336()
{
    return 2797846921U;
}

unsigned addval_131(unsigned x)
{
    return x + 3286272330U;
}

unsigned getval_186()
{
    return 3525888649U;
}

void setval_405(unsigned *p)
{
    *p = 3383020169U;
}

unsigned getval_431()
{
    return 3229141641U;
}

unsigned getval_327()
{
    return 3385115017U;
}

void setval_285(unsigned *p)
{
    *p = 3247144542U;
}

unsigned addval_195(unsigned x)
{
    return x + 3677935243U;
}

unsigned addval_452(unsigned x)
{
    return x + 2495711621U;
}

unsigned addval_362(unsigned x)
{
    return x + 3767093430U;
}

unsigned getval_118()
{
    return 3281043849U;
}

void setval_294(unsigned *p)
{
    *p = 3680551305U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
